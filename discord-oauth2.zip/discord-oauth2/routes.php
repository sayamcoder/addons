<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

Route::get('/auth/discord/redirect', function () {
    // Apni Discord App ID yahan dalna
    $clientId = 'YOUR_DISCORD_CLIENT_ID';
    $redirectUri = urlencode(route('discord.callback'));
    $url = "https://discord.com/api/oauth2/authorize?client_id={$clientId}&redirect_uri={$redirectUri}&response_type=code&scope=identify%20email";
    return redirect($url);
})->name('discord.login');

Route::get('/auth/discord/callback', function (Request $request) {
    // Discord API Logic to get Token & User Data
    $clientId = 'YOUR_DISCORD_CLIENT_ID';
    $clientSecret = 'YOUR_DISCORD_CLIENT_SECRET';
    $redirectUri = route('discord.callback');

    // 1. Exchange code for token
    $response = Http::asForm()->post('https://discord.com/api/oauth2/token', [
        'client_id' => $clientId, 'client_secret' => $clientSecret,
        'grant_type' => 'authorization_code', 'code' => $request->code,
        'redirect_uri' => $redirectUri
    ]);

    $token = $response->json('access_token');
    if (!$token) return redirect('/login')->with('error', 'Discord Login Failed');

    // 2. Get User Info
    $userRes = Http::withToken($token)->get('https://discord.com/api/users/@me');
    $discordUser = $userRes->json();

    // 3. Login or Register in XiyroPanel
    $user = User::firstOrCreate(
        ['email' => $discordUser['email']],
        ['name' => $discordUser['username'], 'password' => bcrypt(str_random(16))] // Random pass
    );

    Auth::login($user);
    return redirect('/dashboard');
})->name('discord.callback');